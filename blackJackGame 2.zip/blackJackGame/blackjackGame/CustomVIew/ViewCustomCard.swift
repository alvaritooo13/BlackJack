//
//  ViewCustomCard.swift
//  blackjackGame
//
//  Created by Apps2t on 20/11/2020.
//
import Foundation
import UIKit

class ViewCustomCard: UIView{

    @IBOutlet var CCView: UIView!
    @IBOutlet weak var cardBackground: UIImageView!
    @IBOutlet weak var numberLB: UILabel!
   
    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
        initSubviews()
    }

    override init(frame: CGRect) {
        super.init(frame: frame)
        initSubviews()
    }
    
    func initSubviews() {
        // standard initialization logic
        let nib = UINib(nibName: "CardView", bundle: nil)
        nib.instantiate(withOwner: self, options: nil)
        CCView.frame = bounds
        addSubview(CCView)

    }
    }
    

