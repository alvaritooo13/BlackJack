//
//  ViewController.swift
//  blackjackGame
//
//  Created by user177270 on 11/12/20.
//

import UIKit

class ViewController: UIViewController,UIGestureRecognizerDelegate{

    
    //Outlets
    @IBOutlet weak var NegativeCustomCard: ViewCustomCard!
    @IBOutlet weak var currentNumberLB: UILabel!
    @IBOutlet weak var PostiveCustomCard: ViewCustomCard!
    
    override func viewDidLoad() {
    super.viewDidLoad()
        
        generateRandomNumbers()
        
        PostiveCustomCard.isUserInteractionEnabled = true
        NegativeCustomCard.isUserInteractionEnabled = true

        //el TapGesture me permite hacer clicable un elemento que no lo es como el label
        let tapLeft: UITapGestureRecognizer = UITapGestureRecognizer( target: self, action: #selector(didTapLeftLabel(sender:)))
       
        PostiveCustomCard.addGestureRecognizer(tapLeft)
        tapLeft.delegate = self
        
    
        let tapRight: UITapGestureRecognizer = UITapGestureRecognizer( target: self, action: #selector(didTapRightLabel(sender:)))
       
        NegativeCustomCard.addGestureRecognizer(tapRight)
        tapRight.delegate = self
        
        
       
    }
  
//funcion que voy a pasar al UITapGestureRecognizer para que la ejecute al pulsar el label
    @objc func didTapLeftLabel(sender: UITapGestureRecognizer)
    {
        let currentTextString = Int(currentNumberLB.text!)!
        let sumNumber = Int(currentNumberLB.text!)! + Int(PostiveCustomCard.numberLB.text!)!
        currentNumberLB.text = String(sumNumber)

       if((currentTextString) <= 0 || (currentTextString) >= 21){
            showAlert()
        }else{
            
            
            let randomInt = Int.random(in: 1..<15)
            PostiveCustomCard.numberLB.text = String(randomInt)

           
        }
         }
    @objc func didTapRightLabel(sender: UITapGestureRecognizer)
    {
        let currentTextString = Int(currentNumberLB.text!)!
        let substractNumber = Int(currentNumberLB.text!)! + Int(NegativeCustomCard.numberLB.text!)!
        currentNumberLB.text = String(substractNumber)

        if((currentTextString) < 0 || (currentTextString) > 21){
            showAlert()
        }else{
            let randomInt = Int.random(in: 1..<15)
            NegativeCustomCard.numberLB.text = "-"+String(randomInt)
        }
    }
    
   
    
   //Generar numeros aleatorios
    func generateRandomNumbers() {
        let randomPosInt = Int.random(in: 1..<10)
        NegativeCustomCard.numberLB.text = "-"+String(randomPosInt)
        let randomNegInt = Int.random(in: 1..<10)
        PostiveCustomCard.numberLB.text = /*"+"+*/String(randomNegInt)
    }
    //Muestra una alerta indicando el final de la partida
    func showAlert(){
        //la variable alert va a mostrar un dialogo en pantalla y toma 3 argumentos, el titulo. la descripcion y el estilo
        let alert = UIAlertController(title: "Game Over", message: "You failed the game, do you want to play again?", preferredStyle: .alert)
        
        //aqui añado las acciones que  van a tener ambos botones del alert como variables
        let ok = UIAlertAction(title: "Yes, restart game", style: .default, handler: { (action) -> Void in
            self.resetGame()
        })
        
       // let cancel = UIAlertAction(title: "Cancel", style: .cancel) { (action) -> Void in
       //     print("Cancel button tapped")}
        
        alert.addAction(ok)
        //alert.addAction(cancel)
  
        self.present(alert, animated: true, completion: nil)
        
    }
    //Reinicia el juego estableciendo nuevos numeros aleatorios y poniendo el contador a cero
    func resetGame(){
        generateRandomNumbers()
       currentNumberLB.text = String(0)

    }
}

