//
//  CardCustomView.swift
//  blackjackGame
//
//  Created by user177270 on 11/12/20.
//

import Foundation
import UIKit

class CardCustomView: UIView {
    
@IBOutlet weak var bgImage: UIImageView!
@IBOutlet weak var button: UIButton!
@IBOutlet weak var view: UIView!

    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
          initSubviews()
      }

      override init(frame: CGRect) {
          super.init(frame: frame)
          initSubviews()
      }

      func initSubviews() {
          // standard initialization logic
          let nib = UINib(nibName: "CardCustomView", bundle: nil)
        nib.instantiate(withOwner: self, options: nil)
          view.frame = bounds
          addSubview(view)

        
      }}
